# Sistema de Venta en Java y Mysql
![java2](https://user-images.githubusercontent.com/71534078/127013163-f5529652-073a-4fcd-ac86-f10611249869.jpg)
